<?php

	require_once 'api/src/apiClient.php';
	require_once 'api/src/contrib/apiPlusService.php';
	require_once 'db_config.php';

	$sql = 'select * from users where important = 1';
	$friends = mysql_query($sql);

	// golim tabela cu activitati
	mysql_query('truncate table activity') or die(mysql_error());

	// parcurgem activitatile prietenilor
	$optParams = array('maxResults' => 25);
	while ($friend = mysql_fetch_array($friends)) {
		$me = $plus->people->get($friend['id'], array());
		$me_img_url = filter_var($me['image']['url'], FILTER_VALIDATE_URL);
		$me_displayName = $me['displayName'];
		
		$sql = 'update users set name = "'.$me_displayName.'", img_url = "'.$me_img_url.'" where id = "'.$friend['id'].'"';
		print_r($sql);
		mysql_query($sql);
		
		$activities = $plus->activities->listActivities($friend['id'], 'public', $optParams);
		foreach ($activities['items'] as $activity) {
			$id = $activity['id'];
			$uid = $activity['actor']['id'];
			$title = filter_var($activity['title'], FILTER_SANITIZE_STRING, FILTER_FLAG_STRIP_HIGH);
			$url = filter_var($activity['url'], FILTER_VALIDATE_URL);
			$published = $activity['published'];
			$updated = $activity['updated'];
			$verb = $activity['verb'];

			if ($verb == 'share') {
				// share
				$post_id = $activity['object']['id'];
			}
			else {
				// postare
				$post_id = $id;
			}

			$post_replies_no = filter_var($activity['object']['replies']['totalItems'], FILTER_SANITIZE_NUMBER_INT);
			$post_replies_url = filter_var($activity['object']['replies']['selfLink'], FILTER_VALIDATE_URL);
			$post_plusoners_no = filter_var($activity['object']['plusoners']['totalItems'], FILTER_SANITIZE_NUMBER_INT);
			$post_plusoners_url = filter_var($activity['object']['plusoners']['selfLink'], FILTER_VALIDATE_URL);
			$post_resharers_no = filter_var($activity['object']['resharers']['totalItems'], FILTER_SANITIZE_NUMBER_INT);
			$post_resharers_url = filter_var($activity['object']['resharers']['selfLink'], FILTER_VALIDATE_URL);
			$post_content = filter_var($activity['object']['content'], FILTER_SANITIZE_STRING, FILTER_FLAG_STRIP_HIGH);
			$post_url = filter_var($activity['object']['url'], FILTER_VALIDATE_URL);

			$sql = 'insert into activity (id, title, content, published, updated, url, uid, verb, replies_no, replies_url, plusoners_no, plusoners_url, resharers_no, resharers_url) 
					values  ("'.$id.'", "'.$title.'", "'.$post_content.'", "'.$published.'", "'.$updated.'", "'.$url.'", "'.$uid.'", "'.$verb.'", '.$post_replies_no.', "'.$post_replies_url.'",
							 '.$post_plusoners_no.', "'.$post_plusoners_url.'", '.$post_resharers_no.', "'.$post_resharers_url.'")';
			mysql_query($sql);
		}
	}

	exit(0);

	$client = new apiClient();
	$client->setApplicationName("Alpha Google+");
	$client->setClientId('998823721064.apps.googleusercontent.com');
	$client->setClientSecret('LX6-uSynT-_1jeXBlFnANos4');
	$client->setRedirectUri('http://localhost/alpha');
	$client->setDeveloperKey('AIzaSyBn_8cxcER3oUX4oo9GsgVFI_37Y4Bk5os');
	$plus = new apiPlusService($client);

	if (isset($_REQUEST['logout'])) {
	  unset($_SESSION['access_token']);
	}

	if (isset($_GET['code'])) {
	  $client->authenticate();
	  $_SESSION['access_token'] = $client->getAccessToken();
	  header('Location: http://' . $_SERVER['HTTP_HOST'] . $_SERVER['PHP_SELF']);
	}

	if (isset($_SESSION['access_token'])) {
	  $client->setAccessToken($_SESSION['access_token']);
	}

	if ($client->getAccessToken()) {

	  $optParams = array('maxResults' => 100);
	  $activities = $plus->activities->listActivities('112471890387110967375', 'public', $optParams);
	  $activityMarkup = '';
	  foreach($activities['items'] as $activity) {
	    // These fields are currently filtered through the PHP sanitize filters.
	    // See http://www.php.net/manual/en/filter.filters.sanitize.php
	    $url = filter_var($activity['url'], FILTER_VALIDATE_URL);
	    $title = filter_var($activity['title'], FILTER_SANITIZE_STRING, FILTER_FLAG_STRIP_HIGH);
	    $content = filter_var($activity['object']['content'], FILTER_SANITIZE_STRING, FILTER_FLAG_STRIP_HIGH);
	    $activityMarkup .= "<div class='activity'><a href='$url'>$title</a></div>";
	  }

	  print '<pre>';
	  print_r($activities);
	  print '</pre>';

	  // The access token may have been updated lazily.
	  $_SESSION['access_token'] = $client->getAccessToken();
	} else {
	  $authUrl = $client->createAuthUrl();
	}

	if(isset($authUrl)) {
	    print "<a class='login' href='$authUrl'>Connect Me!</a>";
	} else {
	   print "<a class='logout' href='?logout'>Logout</a>";
	}

?>