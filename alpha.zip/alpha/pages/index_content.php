<?php
	require_once('db_config.php');

	$sql = 'select * from activity';
	$query = mysql_query($sql);
	
	while ($r = mysql_fetch_array($query)) {
		$sql2 = 'select * from users where id = "'.$r['uid'].'"';
		$user = mysql_fetch_array(mysql_query($sql2));
		echo '
			<table>
				<tr>
					<td valign="top"><img src="'.$user['img_url'].'" width="50" height="50" /></td>
					<td valign="top">
						<a href="'.$r['url'].'">'.$r['title'].'</a><p>'.$r['content'].'</p>
						+'.$r['plusoners_no'].' | Resharers: '.$r['resharers_no'].' | Replies: '.$r['replies_no'].'<br />
						Udated: '.$r['updated'].'<br />
					</td>
				</tr>
			</table><hr />
		';
	}
?>