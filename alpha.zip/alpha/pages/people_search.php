<?php
	require_once('../db_config.php');

	$query = $_GET["query"];
	$token = isset($_GET["pageToken"]) ? $_GET["pageToken"] : "";
	
	 //Set the number of results per page
	 $optParams = array('maxResults' => 10, 'pageToken' => $token);
	
	 //Get the results
	 $results = $plus->people->search($query, $optParams);
	 $token = $results['nextPageToken'];
	 
	 if (isset($results['items']) && !empty($results['items'])) {
		 foreach ($results['items'] as $result)
		 	if ($result['objectType'] == "person") {
			  $id = $result['id'];
			  $url = filter_var($result['url'], FILTER_VALIDATE_URL);
			  $img = filter_var($result['image']['url'], FILTER_VALIDATE_URL);
			  $name = filter_var($result['displayName'], FILTER_SANITIZE_STRING, FILTER_FLAG_STRIP_HIGH);
			  echo '<input type="button" value="Add" onclick="$.ajax({
								type: \'GET\',
								data: { id: \''.$id.'\'},
								url: \'pages/insert_user.php\',
								beforeSend: function () {  },
								success: function(data) {  }
							});" />';
			  ?>
                  <div class="row">
                   <div class="col1"><img src="<?php echo $img ?>"></div>
                   <div class="col2"><a href="<?php echo $url ?>" target="_blank"><?php echo $name ?></a></div>
                  </div>
			  <?php
			}
		
			if (count($results['items']) == 10){			
				?>
				
                <input type="hidden" name="query" value="<?php echo $query ?>" />
				<input type="hidden" id="pageToken" name="pageToken" value="<?php echo $token ?>" />
				<input type="button" id="search_next_page" value="next page"/>
				 <?php
			}
		 }
	?>
	<!--
 <script type="text/javascript">
				  	function addUser(uid) {
					  	xhr = $.ajax({
								type: 'GET',
								data: { id: uid},
								url: 'pages/insert_user.php',
								beforeSend: function () {  },
								success: function(data) { alert(data);  }
							});
					}
				  </script>
                  -->