<?php require_once('db_config.php'); ?>
<div class="left">
	<h2>Your Friends:</h2>
    <div id="friend_results">
		<?php
            $sql = 'select * from users where important = 1 order by timestamp desc';
            $r = mysql_query($sql);
            
            if (mysql_num_rows($r) > 0)
                while ($friend = mysql_fetch_array($r)) {
                    print $friend['name'].'<br />';
                }
            else 
                print 'You are lonely! Go find some friends!';
        ?>
	</div>
</div>
<div class="right">
	<h2>Search:</h2>
    
    <input type="text" id="friend_search_txt" autocomplete="off" /><br /><br />
    <div id="friend_search_results"></div>
    <script type="text/javascript">
		$(document).ready(function () {
			var xhr = null;
			$('#friend_search_txt').change(function () {
				if (xhr != null) xhr.abort();
				xhr = $.ajax({
					type: 'GET',
					data: { query: $(this).val() },
					url: 'pages/people_search.php',
					beforeSend: function () { $('#friend_search_results').html('Searching...'); },
					success: function(data) { 
						$('#friend_search_results').html(data); 
						/*alert('da');
						$('#search_next_page').click(function () {
							alert('click');
							xhr = $.ajax({
								type: 'GET',
								data: { query: $('#friend_search_txt').val(), pageToken: $('#pageToken').val() },
								url: 'pages/people_search.php',
								beforeSend: function () { $('#friend_search_results').html('Searching...'); },
								success: function(data) { $('#friend_search_results').html(data);  }
							});
						});
						*/
					}
				});
			});
		});
	</script>
</div>
<div style="clear: both;"></div>