<?php
	require_once '../db_config.php';
	
	$id = $_GET['id'].'';
	$me = $plus->people->get($id, array());
	
	$name = $me['displayName'];
	$img_url = $me['image']['url'];
	
	$sql = 'insert into users (id, name, img_url, timestamp, important) values ("'.$id.'", "'.$name.'", "'.$img_url.'", unix_timestamp(), 1)';
	mysql_query($sql);
?>