<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Alpha Google+ Manager</title>
<link href="css/style.css" rel="stylesheet" type="text/css" media="all" />
<script type="text/javascript" src="http://code.jquery.com/jquery-latest.min.js"></script>
