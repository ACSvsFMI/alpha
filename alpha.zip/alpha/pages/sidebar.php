<ul>
	<li class="home<?php print strstr($_SERVER['PHP_SELF'], 'index.php') ? '_active' : ''; ?>_btn"> 
		<a href="index.php">
			<div></div>
		    <span>Home</span> 
		</a>
	</li>
    <li class="friends<?php print strstr($_SERVER['PHP_SELF'], 'friends.php') ? '_active' : ''; ?>_btn">
        <a href="friends.php">
            <div></div>
            <span>Friends</span>
        </a>
    </li>
    <li class="sync<?php print strstr($_SERVER['PHP_SELF'], 'sync.php') ? '_active' : ''; ?>_btn">
        <a href="sync.php">
            <div></div>
            <span>Sync</span>
        </a>
    </li>
</ul>

