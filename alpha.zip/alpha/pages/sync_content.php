<?php require_once('db_config.php'); ?>
<div class="left">
	<h2>Sync:</h2>
    <div id="sync_result"></div>
</div>
<div class="right">
	<h2>Search:</h2>
    
    <input type="text" id="friend_search_txt" autocomplete="off" /><br /><br />
    <div id="friend_search_results"></div>
</div>
<div style="clear: both;"></div>

<script type="text/javascript">
	$(document).ready(function () {
		$.ajax({
			type: 'GET',
			data: { query: $(this).val() },
			url: 'crawler.php',
			beforeSend: function () { $('#sync_result').html('Syncing...'); },
			success: function(data) { $('#sync_result').html('Done!'); }
		});
		
		$('#friend_search_txt').change(function () {
			$.ajax({
				type: 'GET',
				data: { query: $(this).val() },
				url: 'pages/people_search.php',
				beforeSend: function () { $('#friend_search_results').html('Searching...'); },
				success: function(data) { $('#friend_search_results').html(data); }
			});
		});
	});
</script>