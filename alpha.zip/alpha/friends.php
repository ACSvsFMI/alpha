<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
	<?php require_once('pages/head.php');	?>
</head>

<body>
    
    <div id="bar"></div>
    <div id="page">
    	<div id="header"></div>
    	<div id="sidebar">
        	<?php require_once('pages/sidebar.php'); ?>
        </div>
        <div id="content">
        	<?php require_once('pages/friends_content.php') ?>
        </div>
        <div style="clear: both;"></div>
    </div>

</body>
</html>
