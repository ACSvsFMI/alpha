<?php

	session_start();
	require_once('api/src/apiClient.php');
	require_once('api/src/contrib/apiPlusService.php');
	
	$host = 'localhost';
	$username = 'root';
	$password = '';
	
	$client = new apiClient();
	$client->setApplicationName("Alpha Google+ Manager");
	$client->setClientId('998823721064.apps.googleusercontent.com');
	$client->setClientSecret('LX6-uSynT-_1jeXBlFnANos4');
	$client->setRedirectUri('http://localhost/alpha/crawler.php');
	$client->setDeveloperKey('AIzaSyBn_8cxcER3oUX4oo9GsgVFI_37Y4Bk5os');
	$plus = new apiPlusService($client);
	
	mysql_connect($host, $username, $password) or die(mysql_error());
	mysql_select_db('alpha') or die(mysql_error());

?>