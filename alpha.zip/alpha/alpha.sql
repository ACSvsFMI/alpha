-- phpMyAdmin SQL Dump
-- version 3.5.2.2
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Dec 08, 2012 at 11:20 PM
-- Server version: 5.5.27
-- PHP Version: 5.4.7

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `alpha`
--

-- --------------------------------------------------------

--
-- Table structure for table `activity`
--

CREATE TABLE IF NOT EXISTS `activity` (
  `id` varchar(70) NOT NULL,
  `title` text NOT NULL,
  `content` text NOT NULL,
  `published` varchar(60) NOT NULL,
  `updated` varchar(60) NOT NULL,
  `url` text NOT NULL,
  `uid` varchar(70) NOT NULL,
  `verb` varchar(10) NOT NULL,
  `replies_no` int(11) NOT NULL,
  `replies_url` text NOT NULL,
  `plusoners_no` int(11) NOT NULL,
  `plusoners_url` text NOT NULL,
  `resharers_no` int(11) NOT NULL,
  `resharers_url` text NOT NULL,
  UNIQUE KEY `id` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `activity`
--

INSERT INTO `activity` (`id`, `title`, `content`, `published`, `updated`, `url`, `uid`, `verb`, `replies_no`, `replies_url`, `plusoners_no`, `plusoners_url`, `resharers_no`, `resharers_url`) VALUES
('z123yz0wbpvjyvpsk22qdtjq2obvd30u0', 'The first step is the toughest, but regrets are tougher to deal with.\n\n#takeachance #life', 'The first step is the toughest, but regrets are tougher to deal with.#takeachance #life', '2012-12-03T05:12:28.688Z', '2012-12-03T05:12:45.000Z', 'https://plus.google.com/110236707457506677404/posts/3nsyS7LqviS', '110236707457506677404', 'post', 393, 'https://www.googleapis.com/plus/v1/activities/z123yz0wbpvjyvpsk22qdtjq2obvd30u0/comments', 1636, 'https://www.googleapis.com/plus/v1/activities/z123yz0wbpvjyvpsk22qdtjq2obvd30u0/people/plusoners', 466, 'https://www.googleapis.com/plus/v1/activities/z123yz0wbpvjyvpsk22qdtjq2obvd30u0/people/resharers'),
('z125yxehotzagp0dt22qdtjq2obvd30u0', 'Daddy&#39;s home!\n\n#puppylove #dogunday', 'Daddy&#39;s home! #puppylove #dogunday', '2012-12-06T04:52:08.630Z', '2012-12-06T04:54:01.000Z', 'https://plus.google.com/110236707457506677404/posts/AY6JM55WXza', '110236707457506677404', 'post', 296, 'https://www.googleapis.com/plus/v1/activities/z125yxehotzagp0dt22qdtjq2obvd30u0/comments', 896, 'https://www.googleapis.com/plus/v1/activities/z125yxehotzagp0dt22qdtjq2obvd30u0/people/plusoners', 97, 'https://www.googleapis.com/plus/v1/activities/z125yxehotzagp0dt22qdtjq2obvd30u0/people/resharers'),
('z12cvvlqpwejd5s2222qdtjq2obvd30u0', 'Truth.\n\n#stupidinlove #love', 'Truth.#stupidinlove #love', '2012-12-06T21:13:31.720Z', '2012-12-06T21:13:41.000Z', 'https://plus.google.com/110236707457506677404/posts/CAa2WgVoqMz', '110236707457506677404', 'post', 103, 'https://www.googleapis.com/plus/v1/activities/z12cvvlqpwejd5s2222qdtjq2obvd30u0/comments', 213, 'https://www.googleapis.com/plus/v1/activities/z12cvvlqpwejd5s2222qdtjq2obvd30u0/people/plusoners', 35, 'https://www.googleapis.com/plus/v1/activities/z12cvvlqpwejd5s2222qdtjq2obvd30u0/people/resharers'),
('z12devrz3my5crzvw22qdtjq2obvd30u0', 'Whoa. &#34;haute heels&#34; indeed.\n\nI call them Sharing My Ankles\n\nimage: someone on facebook who got it from...', 'Whoa. &quot;haute heels&quot; indeed.I call them Sharing My Anklesimage: someone on facebook who got it from Pinterest who got it from my mailbox... etc #highheels #sexy #whatshot', '2012-12-03T03:22:30.130Z', '2012-12-03T03:22:40.000Z', 'https://plus.google.com/110236707457506677404/posts/Mub4rBFzmW9', '110236707457506677404', 'post', 135, 'https://www.googleapis.com/plus/v1/activities/z12devrz3my5crzvw22qdtjq2obvd30u0/comments', 286, 'https://www.googleapis.com/plus/v1/activities/z12devrz3my5crzvw22qdtjq2obvd30u0/people/plusoners', 11, 'https://www.googleapis.com/plus/v1/activities/z12devrz3my5crzvw22qdtjq2obvd30u0/people/resharers'),
('z12ginvbnnehixn2d22qdtjq2obvd30u0', 'Rubber-necking, Gangmobile Style...\n\n#saycheese #humor', 'Rubber-necking, Gangmobile Style...#saycheese #humor', '2012-12-05T20:45:40.290Z', '2012-12-05T20:45:50.000Z', 'https://plus.google.com/110236707457506677404/posts/DK1ya6ERpET', '110236707457506677404', 'post', 380, 'https://www.googleapis.com/plus/v1/activities/z12ginvbnnehixn2d22qdtjq2obvd30u0/comments', 1440, 'https://www.googleapis.com/plus/v1/activities/z12ginvbnnehixn2d22qdtjq2obvd30u0/people/plusoners', 569, 'https://www.googleapis.com/plus/v1/activities/z12ginvbnnehixn2d22qdtjq2obvd30u0/people/resharers'),
('z12hvpzz0yquf1rq204cetb5ysekzh4g3c0', 'Multi-caricature cool.\n\n#drawme #aragon', 'Multi-caricature cool.#drawme #aragon', '2012-12-08T21:22:21.610Z', '2012-12-08T21:23:27.000Z', 'https://plus.google.com/110236707457506677404/posts/ZaCNUPjJN9G', '110236707457506677404', 'post', 13, 'https://www.googleapis.com/plus/v1/activities/z12hvpzz0yquf1rq204cetb5ysekzh4g3c0/comments', 33, 'https://www.googleapis.com/plus/v1/activities/z12hvpzz0yquf1rq204cetb5ysekzh4g3c0/people/plusoners', 3, 'https://www.googleapis.com/plus/v1/activities/z12hvpzz0yquf1rq204cetb5ysekzh4g3c0/people/resharers'),
('z12mc3ejet3kjv4tl22qdtjq2obvd30u0', 'Go go go!\n\nTell us how far you&#39;ve gone to get your girl.\n\n#yourgirl #love #geeklove', 'Go go go!Tell us how far you&#39;ve gone to get your girl.#yourgirl #love #geeklove', '2012-12-06T04:01:03.218Z', '2012-12-06T04:04:40.000Z', 'https://plus.google.com/110236707457506677404/posts/9DsoRwY7YMZ', '110236707457506677404', 'post', 105, 'https://www.googleapis.com/plus/v1/activities/z12mc3ejet3kjv4tl22qdtjq2obvd30u0/comments', 245, 'https://www.googleapis.com/plus/v1/activities/z12mc3ejet3kjv4tl22qdtjq2obvd30u0/people/plusoners', 32, 'https://www.googleapis.com/plus/v1/activities/z12mc3ejet3kjv4tl22qdtjq2obvd30u0/people/resharers'),
('z12msfyygxbgilmz004cetb5ysekzh4g3c0', 'Share if you know this woman. :)\n\n#truth #women #me', 'Share if you know this woman. :)#truth #women #me', '2012-12-06T19:51:48.949Z', '2012-12-06T19:51:59.000Z', 'https://plus.google.com/110236707457506677404/posts/eZpxjaan3tQ', '110236707457506677404', 'post', 58, 'https://www.googleapis.com/plus/v1/activities/z12msfyygxbgilmz004cetb5ysekzh4g3c0/comments', 186, 'https://www.googleapis.com/plus/v1/activities/z12msfyygxbgilmz004cetb5ysekzh4g3c0/people/plusoners', 26, 'https://www.googleapis.com/plus/v1/activities/z12msfyygxbgilmz004cetb5ysekzh4g3c0/people/resharers'),
('z12rh12jjxyrivcp504cetb5ysekzh4g3c0', '#Technology is going to drive people to an infinite madness beyond control.\n\n;)\n\n#google #2084 #earth...', '#Technology is going to drive people to an infinite madness beyond control. ;)#google #2084 #earth#KlaatuBaradaNikto', '2012-12-05T11:34:18.873Z', '2012-12-05T11:34:28.000Z', 'https://plus.google.com/110236707457506677404/posts/UeMCpNJXTBb', '110236707457506677404', 'post', 88, 'https://www.googleapis.com/plus/v1/activities/z12rh12jjxyrivcp504cetb5ysekzh4g3c0/comments', 234, 'https://www.googleapis.com/plus/v1/activities/z12rh12jjxyrivcp504cetb5ysekzh4g3c0/people/plusoners', 66, 'https://www.googleapis.com/plus/v1/activities/z12rh12jjxyrivcp504cetb5ysekzh4g3c0/people/resharers'),
('z12tsrqp0uvzirmyx04cetb5ysekzh4g3c0', 'Cuddle magnet\n\nYou know what day it is...\n\n#caturday #caturdayeveryday\n#cuteness', 'Cuddle magnetYou know what day it is...#caturday #caturdayeveryday#cuteness', '2012-12-08T03:53:38.916Z', '2012-12-08T10:39:40.000Z', 'https://plus.google.com/110236707457506677404/posts/e4j4FuZvXaz', '110236707457506677404', 'post', 500, 'https://www.googleapis.com/plus/v1/activities/z12tsrqp0uvzirmyx04cetb5ysekzh4g3c0/comments', 2205, 'https://www.googleapis.com/plus/v1/activities/z12tsrqp0uvzirmyx04cetb5ysekzh4g3c0/people/plusoners', 535, 'https://www.googleapis.com/plus/v1/activities/z12tsrqp0uvzirmyx04cetb5ysekzh4g3c0/people/resharers'),
('z12txjrjdqjxglp0122qdtjq2obvd30u0', 'Keep Calm and Break The Glass\n\nPenny for your thoughts...\n\nhttp://goo.gl/YHucr\n\n#momoney #different\n#...', 'Keep Calm and Break The GlassPenny for your thoughts...http://goo.gl/YHucr#momoney #different#coolgifts', '2012-12-04T06:02:30.907Z', '2012-12-04T07:17:13.000Z', 'https://plus.google.com/110236707457506677404/posts/1H7S4cFjhea', '110236707457506677404', 'post', 97, 'https://www.googleapis.com/plus/v1/activities/z12txjrjdqjxglp0122qdtjq2obvd30u0/comments', 282, 'https://www.googleapis.com/plus/v1/activities/z12txjrjdqjxglp0122qdtjq2obvd30u0/people/plusoners', 37, 'https://www.googleapis.com/plus/v1/activities/z12txjrjdqjxglp0122qdtjq2obvd30u0/people/resharers'),
('z12whxuhkm3kffpxo04cetb5ysekzh4g3c0', 'In a busy world sometimes it&#39;s best to just do this.\n\n#hugsXinfinity #hugs\n#caturdayeveryday', 'In a busy world sometimes it&#39;s best to just do this.#hugsXinfinity #hugs#caturdayeveryday', '2012-12-06T01:23:15.924Z', '2012-12-06T01:24:03.000Z', 'https://plus.google.com/110236707457506677404/posts/XDrNBYvmJB1', '110236707457506677404', 'post', 53, 'https://www.googleapis.com/plus/v1/activities/z12whxuhkm3kffpxo04cetb5ysekzh4g3c0/comments', 275, 'https://www.googleapis.com/plus/v1/activities/z12whxuhkm3kffpxo04cetb5ysekzh4g3c0/people/plusoners', 41, 'https://www.googleapis.com/plus/v1/activities/z12whxuhkm3kffpxo04cetb5ysekzh4g3c0/people/resharers'),
('z12xyd4pln3bclvyr04cetb5ysekzh4g3c0', 'Exactly.\n\n#newyears2013 #settinghigherstandards', 'Exactly.#newyears2013 #settinghigherstandards', '2012-12-07T15:07:43.663Z', '2012-12-07T15:12:06.000Z', 'https://plus.google.com/110236707457506677404/posts/d7BrpaL2NJv', '110236707457506677404', 'post', 343, 'https://www.googleapis.com/plus/v1/activities/z12xyd4pln3bclvyr04cetb5ysekzh4g3c0/comments', 798, 'https://www.googleapis.com/plus/v1/activities/z12xyd4pln3bclvyr04cetb5ysekzh4g3c0/people/plusoners', 82, 'https://www.googleapis.com/plus/v1/activities/z12xyd4pln3bclvyr04cetb5ysekzh4g3c0/people/resharers'),
('z134cveonozutlatl22qdtjq2obvd30u0', 'Spectacular sky.\n\nPhoto: Michelle Bottcher\n\n#reflections #beautiful', 'Spectacular sky.Photo: Michelle Bottcher#reflections #beautiful', '2012-12-03T02:14:02.477Z', '2012-12-03T02:15:14.000Z', 'https://plus.google.com/110236707457506677404/posts/9ERWG8aSTM1', '110236707457506677404', 'post', 54, 'https://www.googleapis.com/plus/v1/activities/z134cveonozutlatl22qdtjq2obvd30u0/comments', 239, 'https://www.googleapis.com/plus/v1/activities/z134cveonozutlatl22qdtjq2obvd30u0/people/plusoners', 32, 'https://www.googleapis.com/plus/v1/activities/z134cveonozutlatl22qdtjq2obvd30u0/people/resharers'),
('z13cjvajix2fwrp1v22qdtjq2obvd30u0', 'Space Invaders Couch!\n\nWouldn&#39;t you love to have one of these?\n\nAn instant conversation starter, this...', 'Space Invaders Couch!Wouldn&#39;t you love to have one of these?An instant conversation starter, this unique retro gaming inspired couch will be the highlight of any room. Designed and manufactured in Los Angeles, California; to insure the highest build quality. It features and all fine leather pixelated retro design, a low profile, and memory foam cushions. This is a limited production and will only be available for a short time.Source:http://www.igorchak.com/store/# #Gaming    #SpaceInvaders  You&#39;ll love this +Krystyn Chong! :)', '2012-12-03T02:59:22.354Z', '2012-12-03T03:02:06.000Z', 'https://plus.google.com/110236707457506677404/posts/AynXK2xK2nT', '110236707457506677404', 'share', 15, 'https://www.googleapis.com/plus/v1/activities/z13cjvajix2fwrp1v22qdtjq2obvd30u0/comments', 64, 'https://www.googleapis.com/plus/v1/activities/z13cjvajix2fwrp1v22qdtjq2obvd30u0/people/plusoners', 6, 'https://www.googleapis.com/plus/v1/activities/z13cjvajix2fwrp1v22qdtjq2obvd30u0/people/resharers'),
('z13dwjh4svmtsdvyf04cetb5ysekzh4g3c0', 'Not the #droid we&#39;re looking for, but he&#39;ll do.\n\nFor the girl on the run.\n\n#blowmedown #wetnails\n#giftsforher...', 'Not the #droid we&#39;re looking for, but he&#39;ll do.For the girl on the run.#blowmedown #wetnails#giftsforher', '2012-12-04T08:31:44.502Z', '2012-12-04T08:41:48.000Z', 'https://plus.google.com/110236707457506677404/posts/b6meGt2UZgN', '110236707457506677404', 'post', 70, 'https://www.googleapis.com/plus/v1/activities/z13dwjh4svmtsdvyf04cetb5ysekzh4g3c0/comments', 177, 'https://www.googleapis.com/plus/v1/activities/z13dwjh4svmtsdvyf04cetb5ysekzh4g3c0/people/plusoners', 10, 'https://www.googleapis.com/plus/v1/activities/z13dwjh4svmtsdvyf04cetb5ysekzh4g3c0/people/resharers'),
('z13ed1uantjlun25q04cetb5ysekzh4g3c0', 'Exactly.\n\n#foolish #setup\n#repeatoffender', 'Exactly.#foolish #setup#repeatoffender', '2012-12-05T03:50:53.546Z', '2012-12-05T03:51:01.000Z', 'https://plus.google.com/110236707457506677404/posts/XTG2SRiGQ7M', '110236707457506677404', 'post', 108, 'https://www.googleapis.com/plus/v1/activities/z13ed1uantjlun25q04cetb5ysekzh4g3c0/comments', 403, 'https://www.googleapis.com/plus/v1/activities/z13ed1uantjlun25q04cetb5ysekzh4g3c0/people/plusoners', 48, 'https://www.googleapis.com/plus/v1/activities/z13ed1uantjlun25q04cetb5ysekzh4g3c0/people/resharers'),
('z13es3vrlmy2tbf4p04cetb5ysekzh4g3c0', '*Pseudo Vader*\n\nStormtrooper 1: Kick a brother when he&#39;s down.\n\nStormtrooper 2: That&#39;s not the droid ...', '*Pseudo Vader*Stormtrooper 1: Kick a brother when he&#39;s down.Stormtrooper 2: That&#39;s not the droid we&#39;re looking for. He just said &quot;teehee&quot;.I smell a rat underneath the cape. #disneyafterdark #forcechoke#starwarstuesday#starwars', '2012-12-04T07:45:01.125Z', '2012-12-04T08:18:53.000Z', 'https://plus.google.com/110236707457506677404/posts/RyqJHbx264U', '110236707457506677404', 'post', 52, 'https://www.googleapis.com/plus/v1/activities/z13es3vrlmy2tbf4p04cetb5ysekzh4g3c0/comments', 276, 'https://www.googleapis.com/plus/v1/activities/z13es3vrlmy2tbf4p04cetb5ysekzh4g3c0/people/plusoners', 24, 'https://www.googleapis.com/plus/v1/activities/z13es3vrlmy2tbf4p04cetb5ysekzh4g3c0/people/resharers'),
('z13igtfzuwfkh31cf22qdtjq2obvd30u0', 'Serene Scene.\n\nimage: 500pix\n\n#beautiful #sunsets', 'Serene Scene.image: 500pix#beautiful #sunsets', '2012-12-07T04:05:54.094Z', '2012-12-07T04:26:24.000Z', 'https://plus.google.com/110236707457506677404/posts/2r9Boo6Kas5', '110236707457506677404', 'post', 112, 'https://www.googleapis.com/plus/v1/activities/z13igtfzuwfkh31cf22qdtjq2obvd30u0/comments', 440, 'https://www.googleapis.com/plus/v1/activities/z13igtfzuwfkh31cf22qdtjq2obvd30u0/people/plusoners', 57, 'https://www.googleapis.com/plus/v1/activities/z13igtfzuwfkh31cf22qdtjq2obvd30u0/people/resharers'),
('z13jhnchlzfyvfyrr04cetb5ysekzh4g3c0', 'seems legit\n\nOne year too late in the making but hope this helps out others.\n\nimage found: FB, where ...', 'seems legitOne year too late in the making but hope this helps out others.image found: FB, where else?#assholealert #fuckyou#life', '2012-12-05T08:16:19.987Z', '2012-12-05T08:27:45.000Z', 'https://plus.google.com/110236707457506677404/posts/iUVJDUrSTSu', '110236707457506677404', 'post', 121, 'https://www.googleapis.com/plus/v1/activities/z13jhnchlzfyvfyrr04cetb5ysekzh4g3c0/comments', 238, 'https://www.googleapis.com/plus/v1/activities/z13jhnchlzfyvfyrr04cetb5ysekzh4g3c0/people/plusoners', 54, 'https://www.googleapis.com/plus/v1/activities/z13jhnchlzfyvfyrr04cetb5ysekzh4g3c0/people/resharers'),
('z13oibzwavmwwv11d22qdtjq2obvd30u0', 'The only way to spoon.\n\nArtist: +Terry Border at bentobjects.blogspot.com\n\nSee this image the way it ...', 'The only way to spoon.Artist: +Terry Border at bentobjects.blogspot.comSee this image the way it should be: &quot;Let&#39;s slip into bed together&quot;http://goo.gl/BmNAl#bananasinbed #bananas', '2012-12-08T10:13:57.149Z', '2012-12-08T19:00:53.000Z', 'https://plus.google.com/110236707457506677404/posts/7s6pguUgFVH', '110236707457506677404', 'post', 345, 'https://www.googleapis.com/plus/v1/activities/z13oibzwavmwwv11d22qdtjq2obvd30u0/comments', 1228, 'https://www.googleapis.com/plus/v1/activities/z13oibzwavmwwv11d22qdtjq2obvd30u0/people/plusoners', 249, 'https://www.googleapis.com/plus/v1/activities/z13oibzwavmwwv11d22qdtjq2obvd30u0/people/resharers'),
('z13pgh4zfo20gzkfy22qdtjq2obvd30u0', 'Just a reminder.\n\n#dontsettle #youarebeautiful', 'Just a reminder. #dontsettle #youarebeautiful', '2012-12-04T12:42:18.146Z', '2012-12-04T12:42:28.000Z', 'https://plus.google.com/110236707457506677404/posts/NALCatswZtm', '110236707457506677404', 'post', 132, 'https://www.googleapis.com/plus/v1/activities/z13pgh4zfo20gzkfy22qdtjq2obvd30u0/comments', 346, 'https://www.googleapis.com/plus/v1/activities/z13pgh4zfo20gzkfy22qdtjq2obvd30u0/people/plusoners', 83, 'https://www.googleapis.com/plus/v1/activities/z13pgh4zfo20gzkfy22qdtjq2obvd30u0/people/resharers'),
('z13tshs40vfacx4km22qdtjq2obvd30u0', 'See this!? Alice needs to pay me some royalties...\n\n#eatme #drinkme #beliketetris', 'See this!? Alice needs to pay me some royalties...#eatme #drinkme #beliketetris ', '2012-12-08T00:09:23.010Z', '2012-12-08T00:35:39.000Z', 'https://plus.google.com/110236707457506677404/posts/42zjdW69PHC', '110236707457506677404', 'post', 92, 'https://www.googleapis.com/plus/v1/activities/z13tshs40vfacx4km22qdtjq2obvd30u0/comments', 175, 'https://www.googleapis.com/plus/v1/activities/z13tshs40vfacx4km22qdtjq2obvd30u0/people/plusoners', 6, 'https://www.googleapis.com/plus/v1/activities/z13tshs40vfacx4km22qdtjq2obvd30u0/people/resharers'),
('z13tvlub2wiwjhk4j04cetb5ysekzh4g3c0', 'Exactly.\n\n#LOTR #quotes', 'Exactly.#LOTR #quotes', '2012-12-08T21:26:26.280Z', '2012-12-08T21:28:00.000Z', 'https://plus.google.com/110236707457506677404/posts/R1CbRXsdnGz', '110236707457506677404', 'post', 9, 'https://www.googleapis.com/plus/v1/activities/z13tvlub2wiwjhk4j04cetb5ysekzh4g3c0/comments', 27, 'https://www.googleapis.com/plus/v1/activities/z13tvlub2wiwjhk4j04cetb5ysekzh4g3c0/people/plusoners', 8, 'https://www.googleapis.com/plus/v1/activities/z13tvlub2wiwjhk4j04cetb5ysekzh4g3c0/people/resharers'),
('z13xwzkbhvmvsjnao04cetb5ysekzh4g3c0', 'One from this past January. Goodbye 2012, hello 2013!\n\n#bekind #happynewyear', 'One from this past January. Goodbye 2012, hello 2013!#bekind #happynewyear', '2012-12-08T06:46:08.414Z', '2012-12-08T06:46:22.000Z', 'https://plus.google.com/110236707457506677404/posts/cZRwoRZnyt6', '110236707457506677404', 'post', 184, 'https://www.googleapis.com/plus/v1/activities/z13xwzkbhvmvsjnao04cetb5ysekzh4g3c0/comments', 518, 'https://www.googleapis.com/plus/v1/activities/z13xwzkbhvmvsjnao04cetb5ysekzh4g3c0/people/plusoners', 8, 'https://www.googleapis.com/plus/v1/activities/z13xwzkbhvmvsjnao04cetb5ysekzh4g3c0/people/resharers');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE IF NOT EXISTS `users` (
  `id` varchar(60) NOT NULL,
  `name` varchar(60) NOT NULL,
  `img_url` text NOT NULL,
  `timestamp` int(11) NOT NULL,
  `important` tinyint(1) NOT NULL,
  UNIQUE KEY `id` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `img_url`, `timestamp`, `important`) VALUES
('', 'Alexandru Mihai', 'https://lh3.googleusercontent.com/-qRRTml2tDMo/AAAAAAAAAAI/AAAAAAAAAHQ/iPCg35Y5c9g/photo.jpg?sz=50', 1355004561, 1),
('106179876907007704256', 'Mihai Claudiu Toader', 'https://lh4.googleusercontent.com/-XJhIf4Wf3IE/AAAAAAAAAAI/AAAAAAAACqg/JSr5bnTYhAw/photo.jpg?sz=50', 1355005126, 1),
('106949347249024151771', 'Mihia Solto', 'https://lh6.googleusercontent.com/-217dE0OPwzA/AAAAAAAAAAI/AAAAAAAAAAA/JFgrAPLrWb8/photo.jpg?sz=50', 1355004750, 1),
('106949347249024160000', 'Ionut Laceanu', 'https://lh6.googleusercontent.com/-byRRA3OArdg/AAAAAAAAAAI/AAAAAAAAAP0/DfXauqcEifM/photo.jpg?sz=50', 1355004385, 1),
('110236707457506677404', 'Krystyn Chong', 'https://lh6.googleusercontent.com/-ybaP9_Ke3qw/AAAAAAAAAAI/AAAAAAACGfQ/j27k2V2Y8_8/photo.jpg?sz=50', 1354996951, 1),
('111567061469336027617', 'Mihai Parparita', 'https://lh6.googleusercontent.com/-Vje45iqT3_o/AAAAAAAAAAI/AAAAAAAALAc/-3jPlM2RQqg/photo.jpg?sz=50', 1355005101, 1);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
